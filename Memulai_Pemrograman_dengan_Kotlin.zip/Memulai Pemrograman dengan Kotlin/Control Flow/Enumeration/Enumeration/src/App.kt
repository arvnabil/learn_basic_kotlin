// main function
fun main() {
    val color : Color = Color.RED
    val red : Color = Color.GREEN
    println(color)
    print(red)

}

enum class Color{
    RED, GREEN, BLUE
}